/* SC 𝚆𝚈𝙸 𝙾𝙵𝙵𝙸𝙲𝙸𝙰𝙻 V8
BASE : HW MODS
RECODE : 𝚆𝚈𝙸 𝙾𝙵𝙵𝙸𝙲𝙸𝙰𝙻
CREACOT : 𝚆𝚈𝙸 𝙾𝙵𝙵𝙸𝙲𝙸𝙰𝙻
*/

const fs = require('fs')
const chalk = require('chalk')

global.owner = "6285814549423"
global.namabot = "𝚆𝚈𝙸 𝙾𝙵𝙵𝙸𝙲𝙸𝙰𝙻"
global.botname = "𝚆𝚈𝙸 𝙱𝙾𝚃𝚉"
global.autoJoin = false
global.codeInvite = "FwtMxovJqW3Jj55x524hjT"
global.thumb = fs.readFileSync("./thumb.png")
global.sessionName = 'ikyyoffc' //Gausah Juga
global.bugthomz = fs.readFileSync("./bugthomz.png")
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.packname = ""
global.author = "Sticker By 𝚆𝚈𝙸 𝙾𝙵𝙵𝙲🥵"

global.namastore = "𝚆𝚈𝙸 𝙾𝙵𝙵𝙸𝙲𝙸𝙰𝙻"
global.nodana = "085814549423"
global.nogopay = "085814549423"
global.shopepay = "limit"
global.qris = "https://telegra.ph/file/f5d87db0fc66d0185ec54.jpg"

global.domain = '' // Isi Domain Lu
global.apikey = '' // Isi Apikey Plta Lu
global.capikey = '' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

global.antilink = false

const mess = {
   wait: "Tunggu Bang Lagi Saya Proses",
   success: "sukses✅ Bang",
   save: "𝕊𝕌𝕂𝕊𝔼𝕊 𝕊𝔸𝕍𝔼 ℕ𝕆𝕄𝔼ℝ 𝕆𝕋𝕆𝕄𝔸𝕋𝕀𝕊",
   on: "Sudah Aktif", 
   off: "Sudah Off",
   query: {
       text: "Teks Nya Mana Kak?",
       link: "Link Nya Mana Kak?",
   },
   error: {
       fitur: "Mohon Maaf Kak Fitur Eror Silahkan Chat Developer Bot Agar Bisa Segera Diperbaiki",
   },
   only: {
       group: "Fitur Nya Cuman Bisa Di Dalem Grup Yah Bang 𝚆𝚈𝙸 𝙾𝙵𝙵𝙲",
       private: "Di Chat Pribadi Bang Raihan Art Biar Bisa Di Pake",
       owner: "Ga Usah Pake Fitur Ini Asu Lu Bukan Bang 𝚆𝚈𝙸 𝙾𝚏𝚏𝚌",
       admin: "Ga Usah Pake Fitur Ini Asu Lu Bukan Bang 𝚆𝚈𝙸 𝙾𝚏𝚏𝚌",
       badmin: "Maaf Kak Kaya Nya Kakak Tidak Bisa Menggunakan Fitur Ini Di Karenakan Bot Bukan Admin Group",
       premium: "Maaf Kamu Belum Jadi User Premium Untuk Menjadi User Premium Silahkan Beli Ke Owner Dengan Cara Ketik .owner",
   }
}

global.mess = mess
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})